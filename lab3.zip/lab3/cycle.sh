#/bin/bash
x=2
while true; do
#     x=$(($x*2))
    x=$(( 100*1234 ))
#     echo $x
done
