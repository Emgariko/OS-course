#!/bin/bash
while true; do
    read LINE
    echo $LINE > pipe
done
